/*
 * This file uses the Page Object pattern to define the main page for tests.
 * See docs/e2e-guide.md for more info.
 */

'use strict';

var Main = function() {
  // put shared selectors here
};

module.exports = new Main();
